#Kshitija Anam 18110087

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import math
import cv2
from cv2 import VideoWriter, VideoWriter_fourcc
import sys


# Arm 1
l1 = 10
r1 = l1/2
R1 = 0.02
D1 = 400
m1 = (np.pi * (R1**2) * l1) * D1
J1 = (1 / 3) * m1 * l1 * l1
E1 = []

# Arm 2
l2 = 10
r2 = l2/2
R2 = 0.02
D2 = 1000
m2 = (np.pi * (R2**2) * l2) * D2
J2 = (1 / 3) * m2 * l2 * l2
E2 = []

# Arm 3
l3 = 10
r3 = l3/2
R3 = 0.02
D3 = 1000
m3 = (np.pi * (R3 **2) * l3) * D3
J3 = (1 / 3) * m3 * l3 * l3
E3 = []

T = []
g = 9.81
I = 0

tprev = 0


def scara_invkin(x,y,z,l1,l2):
    r = (x**2+y**2-l1**2-l2**2)/(2*l1*l2)
    if r>1 or r<-1:
        print("outside workspace")
        sys.exit()
    theta2 = np.arctan2(np.sqrt(1-r**2),r)
    theta1 = np.arctan2(y,x) - np.arctan2((l2*np.sin(theta2)),(l1+l2*np.cos(theta2)))
    d3 = -z
    print("Theta1 = ", theta1, "\n Theta2 =", theta2,"\n Extension: ", d3, "\n")
    return theta1, theta2, d3


def integrator(E, T):
    n = len(E)
    I = 0
    if n > 30:
        for i in range(n-30, n, 1):
            I = I + E[i]*(T[i] - T[i-1])
    return I

# function for dy/dt
def model(y, t, m1, m2, m3, l1, l2, l3, r1, r2, r3, J1, J2, J3, g, yda, ydb, I):
    theta1 = y[0]
    theta1d = y[1]
    theta2 = y[2]
    theta2d = y[3]
    d = y[4]
    dd = y[5]

    d_theta1 = yda[0] + ((ydb[0] - yda[0])*t)/50
    d_theta2 = yda[1] + ((ydb[1] - yda[1]) * t) / 50
    d_d = yda[2] + ((ydb[2] - yda[2]) * t) / 50

    alpha = J1 + ((r1**2) * m1) + ((l1**2) * m2) + ((l1**2) * m3)
    beta = J2 + J3 + ((l2**2) * m3) + ((r2**2) * m2)
    gamma = l1 * l2 * m3 + l1 * r2 * m2

    e1 = d_theta1 - theta1
    E1.append(e1)

    e2 = d_theta2 - theta2
    E2.append(e2)

    e3 = d_d - d
    E3.append(e3)

    T.append(t)

    I1 = integrator(E1, T)
    I2 = integrator(E2, T)
    I3 = integrator(E3, T)
    #print(e1, e2, e3)

    u1 = -gamma*np.sin(theta2)*theta2d*theta1d - gamma*np.sin(theta2)*(theta2d + theta1d)*theta2d + 10*e1 - 0.7*I1
    u2 = gamma*np.sin(theta2)*theta1d*theta1d - 20*e2 - 0.2*I2
    u3 = -m3*g + 10*e3 - 0.1*I3

    M = np.array([[alpha + beta + 2*gamma*np.cos(theta2), beta + 2*gamma*np.cos(theta2), 0],
                   [beta + 2*gamma*np.cos(theta2), beta, 0], 
                   [0, 0, m3]])
    C = np.array([[-gamma*np.sin(theta2)*theta2d, -gamma*np.sin(theta2)*(theta2d + theta1d), 0],
                  [gamma*np.sin(theta2)*theta1d, 0, 0],
                  [0, 0, 0]])
    G = np.transpose(np.array([0, 0, m3*g]))

    U = np.transpose(np.array([u1, u2, u3]))

    W = (U - np.matmul(C, np.transpose([theta1d, theta2d, dd])) - G)

    dydt = np.matmul(np.linalg.inv(M), W)

    yd = np.array([theta1d, dydt[0], theta2d, dydt[1], dd, dydt[2]])

    tprev = t

    return yd

# initial condition
A = [6, 8, 9]
B = [4, 6, 7]

yda = scara_invkin(A[0], A[1], A[2], l1, l2)
ydb = scara_invkin(B[0], B[1], B[2], l1, l2)

y0 = np.array([yda[0], 0, yda[1], 0, yda[2], 0])

# time points
t = np.linspace(0, 50, num=1000)

# solve ODE
y = odeint(model, y0, t, args=(m1, m2, m3, l1, l2, l3, r1, r2, r3, J1, J2, J3, g, yda, ydb, I))
print(yda, ydb)

plt.plot(t, y[:, 4], color='r', label='Phi')

plt.grid()
plt.show()
print(len(T))
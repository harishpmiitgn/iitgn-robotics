#Kshitija Anam 18110087

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import math
import cv2
from cv2 import VideoWriter, VideoWriter_fourcc
import sys


# Arm 1
l1 = 10
r1 = l1/2
R1 = 0.02
D1 = 400
m1 = (np.pi * (R1**2) * l1) * D1
J1 = (1 / 3) * m1 * (l1**2)
E1 = []

# Arm 2
l2 = 10
r2 = l2/2
R2 = 0.02
D2 = 1000
m2 = (np.pi * (R2**2) * l2) * D2
J2 = (1 / 3) * m2 * (l2**2)
E2 = []

# Arm 3
l3 = 10
r3 = l3/2
R3 = 0.02
D3 = 1000
m3 = (np.pi * (R3 **2) * l3) * D3
J3 = (1 / 3) * m3 * (l3**2)
E3 = []

T = []
g = 9.81
I = 0

tprev = 0


def puma_invkin(x,y,z,l1,l2,l3):
    theta1 = np.arctan2(y,x) - np.arctan2(l3, np.sqrt(x**2 +y**2+l3**2))
    D = (x**2+y**2+z**2-l2**2-l3**2)/(2*l2*l3)
    if D>1 or D<-1:
        print("outside workspace")
        sys.exit()
    theta3 = np.arctan2(np.sqrt(1-D**2), D)
    theta2 = np.arctan2(z-l1,np.sqrt(x**2+y**2))-np.arctan2(l3*np.sin(theta3),l2+l3*np.cos(theta3))
    print("Theta1 = ", theta1, "\n Theta2 =", theta2,"\n Theta3: ", theta3, "\n")
    return theta1, theta2, theta3


def integrator(E, T):
    n = len(E)
    I = 0
    if n > 30:
        for i in range(n-30, n, 1):
            I = I + E[i]*(T[i] - T[i-1])
    return I

# function for dy/dt
def model(y, t, m1, m2, m3, l1, l2, l3, r1, r2, r3, J1, J2, J3, g, yda, ydb, I):
    theta1 = y[0]
    theta1d = y[1]
    theta2 = y[2]
    theta2d = y[3]
    theta3 = y[4]
    theta3d = y[5]

    d_theta1 = yda[0] + ((ydb[0] - yda[0]) * t) / 50
    d_theta2 = yda[1] + ((ydb[1] - yda[1]) * t) / 50
    d_theta3 = yda[2] + ((ydb[2] - yda[2]) * t) / 50

    e1 = d_theta1 - theta1
    E1.append(e1)

    e2 = d_theta2 - theta2
    E2.append(e2)

    e3 = d_theta3 - theta3
    E3.append(e3)

    T.append(t)

    I1 = integrator(E1, T)
    I2 = integrator(E2, T)
    I3 = integrator(E3, T)
    #print(e1, e2, e3)

    a1 = ((l2**2) * m3) + ((r2**2) * m2)
    a2 = ((r3**2) * m3)
    a3 = m3*r3*l2
    b1 = (m2*r2 + m3*l2)*g
    b2 = m3*r3*g
    kp = [1,1,1]
    ki = [1,1,1]

    u1 = kp[0]*e1 + ki[0]*I1
    u2 = b1*np.cos(theta2) + b2*np.cos(theta2 + theta3) + kp[1]*e2 + ki[1]*I2
    u3 = b2*np.cos(theta2 + theta3) + kp[2]*e3 + ki[2]*I3

    M = np.array([[a1*(np.cos(theta2)**2) + a2*(np.cos(theta2+theta3)**2)  + 2*a3*np.cos(theta2)*np.cos(theta2+theta3) + J1, 0, 0],
                   [0, a1 + a2 + 2*a3*np.cos(theta3) + J2, a2 + a3*np.cos(theta3)], 
                   [0, a2 + a3*np.cos(theta3), a3 + J3]])
    C = np.array([[-0.5*a1*np.sin(2*theta2)*theta2d - 0.5*a2*np.sin(2*(theta2+theta3))*(theta2d+theta3d) - a3*np.sin(2*theta2+theta3)*theta2d - a3*np.cos(theta2)*np.sin(theta2+theta3)*theta3d, -0.5*a1*np.sin(2*theta2)*theta1d - 0.5*a2*np.sin(2*(theta2+theta3))*(theta1d) - a3*np.sin(2*theta2+theta3)*theta1d , - 0.5*a2*np.sin(2*(theta2+theta3))*(theta1d) - a3*np.cos(theta2)*np.sin(theta2+theta3)*theta1d],
                  [0.5*a1*np.sin(2*theta2)*theta1d + 0.5*a2*np.sin(2*(theta2+theta3))*(theta1d) + a3*np.sin(2*theta2+theta3)*theta1d, -a3*np.sin(theta3)*theta3d, -a3*np.sin(theta3)*(theta2d+theta3d)],
                  [0.5*a2*np.sin(2*(theta2+theta3))*(theta1d) + a3*np.cos(theta2)*np.sin(theta2+theta3)*theta1d, a3*np.sin(theta3)*theta2d, 0]])
    G = np.transpose(np.array([0, b1*np.cos(theta2) + b2*np.cos(theta2+theta3), b2*np.cos(theta2+theta3)]))

    U = np.transpose(np.array([u1, u2, u3]))

    W = (U - np.matmul(C, np.transpose([theta1d, theta2d, theta3d])) - G)

    dydt = np.matmul(np.linalg.inv(M), W)

    yd = np.array([theta1d, dydt[0], theta2d, dydt[1], theta3d, dydt[2]])

    tprev = t

    return yd

# initial condition
A = [6, 8, 9]
B = [4, 6, 7]

yda = puma_invkin(A[0], A[1], A[2], l1, l2, l3)
ydb = puma_invkin(B[0], B[1], B[2], l1, l2, l3)

y0 = np.array([yda[0], 0, yda[1], 0, yda[2], 0])

# time points
t = np.linspace(0, 50, num=1000)

# solve ODE
y = odeint(model, y0, t, args=(m1, m2, m3, l1, l2, l3, r1, r2, r3, J1, J2, J3, g, yda, ydb, I))
print(yda, ydb)

plt.plot(t, y[:, 4], color='r', label='Phi')

plt.grid()
plt.show()
print(len(T))